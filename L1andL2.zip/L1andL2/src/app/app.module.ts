import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { IgxDropDownModule, IgxButtonModule ,IgxToggleModule } from 'igniteui-angular';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './components/home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { UserloginComponent } from './components/userlogin/userlogin.component';
import { FormComponent } from './components/form/form.component';
import { L1formComponent } from './components/l1form/l1form.component';
import { L2formComponent } from './components/l2form/l2form.component';
import { UseridComponent } from './components/userid/userid.component';
import { Level2Component } from './components/level2/level2.component';
import { AdminComponent } from './components/admin/admin.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    UserloginComponent,
    FormComponent,
    L1formComponent,
    L2formComponent,
    UseridComponent,
    Level2Component,
    AdminComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxPaginationModule,
    // IgxDropDownModule,
    // IgxToggleModule,
    // IgxButtonModule, 
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
