import { Component, OnInit } from '@angular/core';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-l1form',
  templateUrl: './l1form.component.html',
  styleUrls: ['./l1form.component.css']
})
export class L1formComponent implements OnInit {
  textBoxDisabled = true;

  toggle(){
    this.textBoxDisabled = !this.textBoxDisabled;
  }
  
  Form: FormGroup;
  submitted:boolean= false;
  invalidLogin: boolean=false;
  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.Form = this.formBuilder.group({
      text1: ['', Validators.required]
  
    });
  }
  onSubmit() {
    this.submitted = true;
    // If validation failed, it should return 
    // to Validate again
    if (this.Form.invalid) {
    return;
    }
  
    this.router.navigate(['level2']);
    }


}
