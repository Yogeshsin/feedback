import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userid',
  templateUrl: './userid.component.html',
  styleUrls: ['./userid.component.css']
})
export class UseridComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
