export class Login{
     id:string;
     email:String;
     password:String
}